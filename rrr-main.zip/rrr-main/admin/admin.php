<?php
session_start();

$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "rrr";

$con = new mysqli($host, $dbusername, $dbpassword, $dbname);


if(isset($_POST['login'])){
$email = mysqli_real_escape_string($con, $_POST['email']);
$pswd = mysqli_real_escape_string($con, $_POST['pswd']);

$_SESSION["status"]=false;

if(!empty($email) && !empty($pswd) ){

   $query = "select * from admin where email = '$email' AND pswd = '$pswd'";
   $result = mysqli_query($con, $query);
    
   if($result)
          {
             if($result && mysqli_num_rows($result) > 0)
             {
 
                $user_data = mysqli_fetch_assoc($result);
                
                if($user_data['pswd'] === $pswd)
                {
 
                  $_SESSION["status"] = true; 
                  header("Location: adminmain.php");
                   die;
                }
             }
          }
          
       ?>
              <script>
                  alert("Wrong email or Password");
              </script>
           <?php 
          
       }else
       {
       ?>
       <script>
           alert("Wrong email or Password");
       </script>
    <?php 
       }
 }

?>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
     <link rel="stylesheet" href="login_main.css">
     <script src="https://kit.fontawesome.com/0715c7df9a.js" crossorigin="anonymous"></script>
</head>
<body>
    
    
    <div class="login-form"><div class="text">ADMIN LOGIN</div>
<form action="admin.php" method="post">
  <div class="field">
    <div class="fas fa-envelope">
  </div>
<input type="text" name= "email" placeholder="Email" required>
  </div>
<div class="field">
   <div class="fas fa-lock">
</div>
<input type="password" name="pswd" placeholder="Password" required>
   </div>
<button name="login">LOG IN</button>
   </div>

</form>
</div>
</body>
</html>