<?php
session_start();

$server = "localhost";
$user = "root";
$password = "";
$db = "rrr";

$con = mysqli_connect($server,$user,$password,$db);
if(!$con) {
    echo "Connection Unsuccessful";
}

$query = "select * from signup";
$result = mysqli_query($con,$query);

?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RAGS TO REACHES</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.3/css/bulma.min.css">
    <style>@import "admin.css";</style>
</head>
<body>
<script src="https://kit.fontawesome.com/0715c7df9a.js" crossorigin="anonymous">
  $(".Navigation-list-item").on("click", function () {
  $(".Navigation-list-item").removeClass("active");
  $(this).addClass("active");
});

$(".pins").masonry({
  // options
  itemSelector: ".pin",
  columnWidth: 400,
  fitWidth: true,
  transitionDuration: "0.2s"
});

</script>
	
<div id="Navigation">
  <div class="Main-navigation">
    <div  style="height: 15%; width: 40%;display: block; margin: 5px 25px">
      <img src="RR.png">
    </div>

    <div class="Navigation-items">
      <ul class="Navigation-list">

      <li class="Navigation-list-item">
          <span class="Navigation-icon accent">
           <i class="fas fa-praying-hands"></i>
          </span>
          <a href="adminmain.php">
            <span class="Navigation-title has-text-grey-light">Donations</span>
          </a>
        </li>

        <li class="Navigation-list-item">
          <span class="Navigation-icon accent">
           <i class="fas fa-praying-hands"></i>
          </span>
          <a href="adminsignup.php">
            <span class="Navigation-title has-text-grey-light">Sign Up</span>
          </a>
        </li>
        
        <li class="Navigation-list-item">
          <span class="Navigation-icon accent">
           <i class="fas fa-praying-hands"></i>
          </span>
          <a href="adminngo.php">
            <span class="Navigation-title has-text-grey-light">NGO Details</span>
          </a>
        </li>

        <li class="Navigation-list-item">
          <span class="Navigation-icon accent">
		  <i class="fas fa-bars"></i>
            
          </span>
          <span class="Navigation-title">Menu</span>
          <ul class="Secondary-nav-list">
            <li class="Secondary-nav-list-item">
              <span class="Navigation-icon accent">
              <i class="fa fa-address-book-o"></i>
              </span>
              <a href="index_main.php">
              <span class="Navigation-title">Main Page</span>
              </a>
              <span class="Sub-nav-arrow"></span>
            </li>
           
			 <hr class="navbar-divider">
            <li class="Secondary-nav-list-item">
              <span class="Navigation-icon accent">
              <i class="fa fa-user-o"></i>
              </span>
              <a href="aboutus.html">
              <span class="Navigation-title">About Us</span>
              </a>
              <span class="Sub-nav-arrow"></span>
            </li>
		 
			
            </li>
            
          </ul>
        </li>
    
        
        <hr> 
		<li class="Navigation-list-item">
          <span class="Navigation-icon accent">
           <i class="fas fa-link"></i>
          </span>		  
          <span class="Navigation-title">Connect with Us</span>
		  <ul>
		  <li style="list-style: none;  margin:20 0 0 30;  display: inline-block;"><a href="https://www.facebook.com/home.php" style="color:#999fa2;text-decoration:none;"><i class="fab fa-facebook"></a></i></li>
		  <li style="list-style: none;  margin: 0 40px 0 40;  display: inline-block;"><a href="https://www.instagram.com/" style="color:#999fa2;text-decoration:none;"><i class="fab fa-instagram"></a></i></li>
		  <li style="list-style: none;  margin: 0 40px 0 0;  display: inline-block;"><a href="https://www.youtube.com/" style="color:#999fa2;text-decoration:none;"><i class="fab fa-youtube"></a></i></li>
		  <li style="list-style: none;  margin: 0 40px 0 0;  display: inline-block;"><a href="https://www.twitter.com/" style="color:#999fa2;text-decoration:none;"><i class="fab fa-twitter"></a></i></li>
		  </li></ul>
		  <hr style="margin-top:0px;">
		  
		 <span class="Navigation-title" style="margin:20 0 0 30;">RAGS TO REACHES © 2020</span> 
		  
		</UL>
		
      
      <span class="divider"></span>
      
    </div>
  </div>
</div>
        </li>
      </ul>
      </div>
      </div>
      </div>
      

      <div class="table-container">
       <table class="table is-bordered is-striped has-text-centered is-hoverable sticky" style="width: 1135px;margin-left: 310px; padding: 2px;">
        <tr>
          <th class="thead has-text-centered  is-selected" colspan="5"><strong>Signup Records</strong></th>
        </tr>
        <t class="thead py-2">
          <th> ID </th>
          <th> Name </th>
          <th> Email </th>
          <th> Phone </th>
          <th> Gender</th>
        </t>
        <?php 
            while($rows=mysqli_fetch_assoc($result))
            {
        ?>

             <tr class="tbody">
               <td><?php echo $rows['id']; ?></td>
               <td><?php echo $rows['name']; ?></td>
               <td><?php echo $rows['email']; ?></td>
               <td><?php echo $rows['phone']; ?></td>
               <td><?php echo $rows['gender']; ?></td>
             </tr>
        <?php
            }
            ?>
        
       </table>
      </div>

      
   <script src="main.js"></script>
</body>
</html>

