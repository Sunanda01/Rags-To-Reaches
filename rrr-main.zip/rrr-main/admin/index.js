$(".Navigation-list-item").on("click", function() {
    $(".Navigation-list-item").removeClass("active");
    $(this).addClass("active");
  });
  
  $('.pins').masonry({
    // options
    itemSelector: '.pin',
    columnWidth: 400,
    fitWidth: true,
    transitionDuration: '0.2s'
  });