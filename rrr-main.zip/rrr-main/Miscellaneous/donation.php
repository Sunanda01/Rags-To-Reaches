<?php
    
    $server = "localhost";
    $user = "root";
    $password = "";
    $db = "rrr";

    $con = mysqli_connect($server,$user,$password,$db);
    if(!$con) {
        echo "Connection Unsuccessful";
    }


    if(isset($_POST['submit'])){

         $name = mysqli_real_escape_string($con, $_POST['name']);
         $email = mysqli_real_escape_string($con, $_POST['email']);
         $phone = mysqli_real_escape_string($con, $_POST['phone']);
         $items = mysqli_real_escape_string($con, $_POST['items']);
         $addr = mysqli_real_escape_string($con, $_POST['addr']);
         $ngo = mysqli_real_escape_string($con, $_POST['ngo']);

         $emailquery = " select * from signup where email= '$email' ";
         $query = mysqli_query($con, $emailquery);

            $emailcount = mysqli_num_rows($query);

            if($emailcount === 0) {
                ?>
                <script>
                    alert("Please Sign Up first.");
                </script>
            <?php 
            }

            else {
                
                $insertquery = "insert into donation( name, email, phone, items, addr, ngo) values('$name','$email','$phone','$items','$addr','$ngo')";

                $iquery = mysqli_query($con, $insertquery);
            }


         
    }
    
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.3/css/bulma.min.css">
</head>
<body style="background: #252627;">
    <div class="container" style="max-width: 50%; ">
        <p class="title has-text-centered has-text-warning">Donation Form</p>
        <form action="donation.php" method="post">
            <div class="field">
                <label class="label has-text-warning">Name</label>
                <div class="control">
                   <input type="text" name="name" class="input" placeholder="Enter your name">
                </div>
            </div>

            <div class="field">
                <label class="label has-text-warning">Email</label>
                <div class="control">
                   <input type="email" name="email" class="input" placeholder="Enter your email">
                </div>
            </div>

            <div class="field">
                <label class="label has-text-warning">Phone Number</label>
                <div class="control">
                   <input type="text" name="phone" class="input" placeholder="Enter your phone number">
                </div>
            </div>

            <div class="field">
                <label class="label has-text-warning">Number of Items Donated</label>
                <div class="control">
                   <input type="number" name="items" class="input" placeholder="Enter number of items">
                </div>
            </div>

            <div class="field">
                <label class="label has-text-warning">Address</label>
                <p class="is-size-7 has-text-danger">Enter the address from where the items will be picked.</p>
                <div class="control">
                   <input type="text" name="addr" class="input" placeholder="Enter the address">
                </div>
            </div>

            <div class="field">
                <label class="label has-text-warning ">NGO Preference, If any</label>
                <div class="control">
                   <input type="text" name="ngo" class="input" placeholder="Enter the name of NGO">
                </div>
            </div>

            <div class="field">
                <div class="control">
                  <label class="checkbox has-text-warning">
                    <input type="checkbox" name="terms"> I agree to the <a href="https://www.lanadelrey.com/">Terms and Conditions</a>
                  </label>
                </div>
              </div>

            <div class="mt-6 has-text-centered">
                <button class="button is-black has-text-primary" name="submit">Donate</button>
            </div>
              
        </form>
    </div>
</body>
</html> 
