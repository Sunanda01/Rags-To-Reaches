<?php
session_start();

$server = "localhost";
$user = "root";
$password = "";
$db = "rrr";

$con = mysqli_connect($server,$user,$password,$db);
if(!$con) {
    echo "Connection Unsuccessful";
}


if(isset($_POST['submit'])){

     $name = mysqli_real_escape_string($con, $_POST['name']);
     $email = mysqli_real_escape_string($con, $_POST['email']);
     $phone = mysqli_real_escape_string($con, $_POST['phone']);
     $dob = mysqli_real_escape_string($con, $_POST['dob']);
     $gender = mysqli_real_escape_string($con, $_POST['gender']);
     $addr = mysqli_real_escape_string($con, $_POST['addr']);
     $pswd = mysqli_real_escape_string($con, $_POST['pswd']);
     $cpswd = mysqli_real_escape_string($con, $_POST['cpswd']);

     $pass = password_hash($pswd, PASSWORD_BCRYPT);
     $cpass = password_hash($cpswd, PASSWORD_BCRYPT);

     $emailquery = " select * from signup where email= '$email' ";
     $query = mysqli_query($con, $emailquery);

     $emailcount = mysqli_num_rows($query);

     if($emailcount>0) {
         ?>
         <script>
             alert("Email already exists.");
         </script>
      <?php 
     }
     else {
         if($pswd === $cpswd){

             $insertquery = "insert into signup( name, email, phone, dob, gender, addr, pswd, cpswd) values('$name','$email','$phone','$dob','$gender','$addr','$pass', '$cpass')";

             $iquery = mysqli_query($con, $insertquery);

             if($iquery){
                    $_SESSION['name'] = $name;
                    $_SESSION['success'] = "You have an account now!";
                    header('location: index_main.php');  
             }
             else {
                 ?>
                     <script>
                         alert("Insertion unsuccessful");
                     </script>
                  <?php   
          }
         }
         else {
             ?>
             <script>
                 alert("Passwords are not matching");
             </script>
          <?php 
         }
     }    
}


?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.3/css/bulma.min.css">
</head>
<body style="background: #252627;">
  <div style="max-width: 50%; margin:auto;">
   <h3 class="title mb-8 has-text-centered has-text-warning">Join The Club</h3>

   <form action="index_main.php" method="post">
     <div class="field">
       <label for="Name" class="label has-text-warning">Name</label>
       <div class="control">
         <input type="text" class="input" name="name" id="name" placeholder="Enter Your Name"  required>
       </div>
     </div>

     <div class="field">
      <label for="Email" class="label has-text-warning">Email</label>
      <div class="control">
        <input type="email" class="input" name="email" id="email" placeholder="Enter Your email" required> 
      </div>
    </div>

    <div class="field">
      <label for="Phone" class="label has-text-warning">Phone Number</label>
      <div class="control">
        <input type="text" class="input" name="phone" id="phone" placeholder="Enter Your Phone Number" required>
      </div>
    </div>

    <div class="field">
      <label class="label has-text-warning">Date of Birth</label>
      <div class="control">
        <input type="date" class="input" name="dob" min="1980-01-01" max="2008-12-31" id="dob" placeholder="Enter Your DOB" required>
      </div>
    </div>

    <div class="field">
      <label class="label has-text-warning">Gender</label>
      <div class="select">
        <select name="gender" id="gender" required> 
          <option>Female</option>
          <option>Male</option>
          <option>Transgender</option>
          <option>Prefer Not to say</option>
        </select>
      </div>
    </div>


    <div class="field">
      <label class="label has-text-warning">Address</label>
      <div class="control">
        <input type="text" class="textarea" name="addr" id="addr" placeholder="Enter Your Address" required>
      </div>
    </div>

    <div class="field">
      <label class="label has-text-warning">Password</label>
      <div class="control">
        <input type="password" class="input" name="pswd" id="pswd" placeholder="Enter Password" required>
      </div>
    </div>

    <div class="field">
      <label class="label has-text-warning">Confirm Password</label>
      <div class="control">
        <input type="password" class="input" name="cpswd" id="cpswd" placeholder="Confirm Password" required>
      </div>
    </div>

    <div class="field">
      <div class="control">
        <label class="checkbox has-text-warning">
          <input type="checkbox" onclick="checkterms()" id="terms"  name="terms"> I agree to the <a href="https://www.lanadelrey.com/">Terms and Conditions</a>
        </label>
      </div>
    </div>

    <div class="mt-6 mb-4 has-text-centered">
      <button class="button is-black has-text-primary" name="submit">Sign Up</button>
    </div>
    <p class="has-text-centered mt-4 has-text-warning">  Already a member? <a href="login_main.php">Log In</a>
   </form>
 </div>
     
</body>
</html>
